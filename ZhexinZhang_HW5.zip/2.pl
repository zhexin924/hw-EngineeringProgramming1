#!/usr/bin/perl -w
@all=glob("*");
foreach(@all)
{
	if(/\s+/)
	{
	$old=$_;
	`chmod 0777 $_`;
	s/\s//g,$_;
	print $_;
	rename ("$old","$_");
}
else
{next;}
}
$path=`pwd`;
print "Now we are at \"$path\"";
print "Please tell me the name and size:\n";
$key1=<STDIN>;
chomp $key1;
$hash{$key1}=<STDIN>;
chomp $hash{$key1};
print "I will creat \"$key1\" for you.";
mkdir ($key1,0777);
@allFiles=glob("*");
print "Any file larger than \"$hash{$key1}\" under \"$path\" will be copied to $path/$key1\n";
foreach(@allFiles)
{
#	print $_;
@args = stat($_);
$size = $args[7];
if(-d)
{
	next;
}
elsif($size>$hash{$key1})
    {
       		`chmod 0777 $_`;
       		chdir ("$key1");
       		$newpath=`pwd`;
#       		print `pwd`;
       		chdir ("..");
#       		print `pwd`;
            system("cp $_ $newpath");

       }

       else

       {
              next;
       }

}
#print $newpath;
chdir ("$key1");

print "Check your new directory \"$key1\",I have listed all the files in it:\n";
#print `pwd`;
system("ls");