#! usr/bin/perl

use warnings;

use strict;

@ARGV=qw(test.txt);

my @list;

 

while (<>)

{

       if(/^\\s*$/)

       {

              next;

       }

       else

       {

              #print;

              push @list,(split /\s+/,$_);

             

       }

}

my $i=0;

open(FH,'|-', 'perl sort.pl');

while($i<$#list)

{

print FH ( "$list[$i]\n");

$i++;

}

close FH;


