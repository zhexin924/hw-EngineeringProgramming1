#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Firewall.h"
using namespace std;
int main()
{
	unsigned int id,port;
	string sourceIP,destinationIP,date,Blocked;
	bool blocked;
	fstream outFirewall("firewall.dat",ios::in|ios::out|ios::binary);
	if(!outFirewall)
	{
		cerr<<"File could not be opened."<<endl;
		exit(EXIT_FAILURE);
	}
	cout<<"Enter ID (1 to 100,0 to end input)\n";
	Firewall firewall;
	cin>>id;
	
	while(id>0 && id<=100)
	{
		cout<<"Enter Source IP,Destination IP,Port,Date,Blocked\n";
		cin>>sourceIP;
		cin>>destinationIP;
		cin>>port;
		cin>>date;
		cin>>Blocked;
		if(Blocked=="Yes"||Blocked=="yes"||Blocked=="YES") blocked=1;
		else if(Blocked=="No"||Blocked=="no"||Blocked=="NO") blocked=0;
		
		//set datas of firewall
		firewall.setID(id);
		firewall.setSourceIP(sourceIP);
		firewall.setDestinationIP(destinationIP);
		firewall.setPort(port);
		firewall.setDate(date);
		firewall.setBlocked(blocked);
		
		//save the datas in increasing order according to their ids
		outFirewall.seekp((firewall.getID()-1)*sizeof(Firewall));
		outFirewall.write(reinterpret_cast<const char*>(&firewall),sizeof(Firewall));
		
		//input new data
		cout<<"Enter ID\n";
		cin>>id;
	}
}