#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include "Firewall.h"

using namespace std;
int main()
{
	ofstream outFirewall("firewall.dat",ios::out|ios::binary);
	if(!outFirewall)
	{
		cerr<<"File could not be opened."<<endl;
		exit(EXIT_FAILURE);
	}
	Firewall blankFirewall;
	for(int i=0;i<100;i++)
		outFirewall.write( reinterpret_cast<const char * > (&blankFirewall),sizeof(Firewall));
}