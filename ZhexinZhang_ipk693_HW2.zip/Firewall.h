
#ifndef FIREWALL_H
#define FIREWALL_H

#include <string>

using namespace std;

class Firewall
{
	public:
		/*default Firewall constructor*/
		Firewall( unsigned int = 0, const std::string & = "",const std::string & = "",unsigned int = 0,const std::string & ="" ,bool=false );
		/*accessor functions for ID*/
		void setID(unsigned int);
		int getID() const;
		
		/*accessor functions for source IP*/
		void setSourceIP(const std::string &);
		std::string getSourceIP() const;
		
		/*accessor functions for destination IP*/
		void setDestinationIP(const std::string &);
		std::string getDestinationIP() const;
		
		/*accessor functions for port*/
		void setPort(unsigned int);
		int getPort() const;
		
		/*accessor functions for Date*/
		void setDate(const std::string &);
		std::string getDate() const;
		
		/*accessor functions for blocked status*/
		void setBlocked(bool);
		bool getBlocked() const;
	private:
		unsigned int id,port;
		char sourceIP[16],destinationIP[16],date[11];
		bool blocked;
	
};

#endif