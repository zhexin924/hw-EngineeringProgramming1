
#include <string>

#include "Firewall.h"

using namespace std;

Firewall::Firewall(unsigned int idNumber,const string &sourceIP,const string &destinationIP, unsigned int portNumber,const string &date,bool blockedStatus )
			: id(idNumber),port(portNumber),blocked(blockedStatus)
	{
		setSourceIP(sourceIP);
		setDestinationIP(destinationIP);
		setDate(date);
	}//end Firewall constructor
	
		int Firewall::getID() const
		{
			return id;
		}
		void Firewall::setID(unsigned int idNumber)
		{
			id=idNumber;
		}
		/*accessor functions for source IP*/
		void Firewall::setSourceIP(const string &sourceIPstring)
		{
			int length=sourceIPstring.size();
			length=(length<16?length:15);
			sourceIPstring.copy(sourceIP,length);
			sourceIP[length]='\0';
		}
		std::string Firewall::getSourceIP() const
		{
			return sourceIP;
		}
		
		/*accessor functions for destination IP*/
		void Firewall::setDestinationIP(const string &destinationIPstring)
		{
			int length=destinationIPstring.size();
			length=(length<16?length:15);
			destinationIPstring.copy(destinationIP,length);
			destinationIP[length]='\0';
		}
		std::string Firewall::getDestinationIP() const
		{
			return destinationIP;
		}
		
		/*accessor functions for port*/
		void Firewall::setPort(unsigned int portNumber)
		{
			port=portNumber;
		}
		int Firewall::getPort() const
		{
			return port;
		}
		
		/*accessor functions for Date*/
		void Firewall::setDate(const string &datestring)
		{
			int length=datestring.size();
			length=(length<10?length:9);
			datestring.copy(date,length);
			date[length]='\0';
		}
		std::string Firewall::getDate() const
		{
			return date;
		}
		
		/*accessor functions for blocked status*/
		void Firewall::setBlocked(bool blockedStatus)
		{
			blocked=blockedStatus;
		}
		bool Firewall::getBlocked() const
		{
			return blocked;
		}