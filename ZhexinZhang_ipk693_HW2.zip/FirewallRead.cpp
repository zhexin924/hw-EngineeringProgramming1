#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include "Firewall.h"
using namespace std;

void outputLine(ostream&,const Firewall & );
void outputAllLine(ostream&,const Firewall & );
int main()
{
	unsigned int ID;
	string Blocked;
	Firewall firewall;
	ifstream inFirewall("firewall.dat",ios::in|ios::binary);
	if(!inFirewall)
	{
		cerr<<"File could not be opened."<<endl;
		exit(EXIT_FAILURE);
	}
	cout<<"Read All? Then press 0 or Enter ID :"<<endl;
	cin>>ID;
	while(ID>100)
	{
		cout<<"Out of range,ID is no more than 100,please enter ID:"<<endl;
		cin>>ID;
	}
	
	
	if(ID!=0)
	{
		
		inFirewall.seekg((ID-1)*sizeof(Firewall));
		if(firewall.getSourceIP()!=""||firewall.getDestinationIP()!=""||firewall.getDate()!="") cout<<left<<setw(4)<<"Id"<<setw(16)<<"Source IP"<<setw(16)<<"Destination IP"<<setw(5)<<"Port"<<setw(11)<<"Date"<<left<<setw(7)<<right<<"Blocked"<<endl;
		inFirewall.read(reinterpret_cast<char *>(&firewall),sizeof(Firewall));
		outputLine(cout,firewall);
	}
	else if(ID==0)
	{
		cout<<left<<setw(4)<<"Id"<<setw(16)<<"Source IP"<<setw(16)<<"Destination IP"<<setw(5)<<"Port"<<setw(11)<<"Date"<<left<<setw(7)<<right<<"Blocked"<<endl;
		inFirewall.read(reinterpret_cast<char *>(&firewall),sizeof(Firewall));
		while(inFirewall && !inFirewall.eof())
		{
			if(firewall.getID()!=0) outputAllLine(cout,firewall);
			inFirewall.read(reinterpret_cast<char *>(&firewall),sizeof(Firewall));
		}
	}
	
}
void outputLine(ostream &output,const Firewall &record)
{
	string Blocked;
	if(record.getBlocked()==0) Blocked="No";
	else Blocked="Yes";
	if(record.getSourceIP()==""||record.getDestinationIP()==""||record.getDate()=="") output<<"No record!"<<endl;
	else 
	{
		cout<<left<<setw(4)<<"Id"<<setw(16)<<"Source IP"<<setw(16)<<"Destination IP"<<setw(5)<<"Port"<<setw(11)<<"Date"<<left<<setw(7)<<right<<"Blocked"<<endl;
		output<<left<<setw(4)<<record.getID()<<setw(16)<<record.getSourceIP()<<setw(16)<<record.getDestinationIP()<<setw(5)<<record.getPort()<<setw(11)<<record.getDate()<<left<<setw(7)<<Blocked<<endl;
	}
}
void outputAllLine(ostream &output,const Firewall &record)
{
	string Blocked;
	if(record.getBlocked()==0) Blocked="No";
	else Blocked="Yes"; 
	output<<left<<setw(4)<<record.getID()<<setw(16)<<record.getSourceIP()<<setw(16)<<record.getDestinationIP()<<setw(5)<<record.getPort()<<setw(11)<<record.getDate()<<left<<setw(7)<<Blocked<<endl;
}

