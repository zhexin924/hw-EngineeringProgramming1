/*************************************************************************
	> File Name: square.h
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:06:07 PM CDT
 ************************************************************************/


#ifndef SQUARE_H
#define SQUARE_H
#include <cstdlib>
#include <iostream>
#include "shape.h"
#include <string>
using namespace std;
class Square: public Shape
{
	public:
		Square(const string &,double=0.0,double=0.0);

		void setWidth(double);	
		double getWidth() const;
		void setHeight(double);
		double getHeight() const;
		void drawSquare(double,double) const;

		virtual void printColor() const override;
		virtual void draw() const override;
		virtual double saveArea() const override;
	protected:
		double Width;
		double Height;
};

#endif
