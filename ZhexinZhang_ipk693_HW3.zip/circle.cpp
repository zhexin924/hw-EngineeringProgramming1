/*************************************************************************
	> File Name: circle.cpp
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:05:42 PM CDT
 ************************************************************************/

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include "shape.h"
#include "circle.h"
#define PI 3.14
using namespace std;

Circle::Circle(const string & color,double radius):Shape(color)
{
	setRadius(radius);
}
void Circle::setRadius(double radius)
{
	Radius=radius;
}
double Circle::getRadius() const
{
	return Radius;
}
void Circle::printColor() const
{
	cout<<"This circle is in ";
	Shape::printColor();
}

void Circle::drawCircle(double r) const
{
	int x,i,y,z;
	z=r*5;
	char ch='\"';
	cout<<"This is a "<<Shape::getColors()<<" circle with radius "<<Radius<<":"<<endl;
	for(y=z;y>=-z;y--)
	{
		i=2.2*sqrt(z*z-y*y);
		for(x=1;x<=3*z-i;x++) 
		{
			//if(((x-z)*(x-z)+2.2*2.2*(y-z)*(y-z))==z*z) cout<<ch;
			//else cout<<" ";
			cout<<" ";
		}
		cout<<ch;
		for(;x<=3*z+i;x++) cout<<" ";
			cout<<ch<<endl;
	} 
		
}
void Circle::draw() const
{

	Circle::drawCircle(Radius);
}
double Circle::saveArea() const
{
	double r=Circle::getRadius();
	cout<<"Circle's area = "<<PI*r*r<<endl;
	return PI*r*r;
}
