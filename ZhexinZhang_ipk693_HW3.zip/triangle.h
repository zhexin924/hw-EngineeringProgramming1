/*************************************************************************
	> File Name: triangle.h
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:06:36 PM CDT
 ************************************************************************/

#include <cstdlib>
#include <iostream>
using namespace std;
#ifndef TRIANGLE_H
#define TRIANGLE_H
#include <cstdlib>
#include <iostream>
#include "shape.h"
#include <string>
using namespace std;
class Triangle: public Shape
{
	public:
		Triangle(const string &,double=0.0,double=0.0);

		void setWidth(double);	
		double getWidth() const;
		void setHeight(double);
		double getHeight() const;
		void drawTriangle(double,double) const;

		virtual void printColor() const override;
		virtual void draw() const override;
		virtual double saveArea() const override;
	private:
		double Width;
		double Height;
};

#endif
