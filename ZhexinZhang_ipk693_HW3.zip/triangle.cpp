/*************************************************************************
	> File Name: triangle.cpp
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:06:45 PM CDT
 ************************************************************************/
#include <cstdlib>
#include <iostream>
#include "shape.h"
#include <string>
#include "triangle.h"	
using namespace std;
Triangle::Triangle(const string & color,double width,double height):Shape(color)
{
	setWidth(width);
	setHeight(height);
}
void Triangle::setWidth(double width)
{
	Width=width;
}	
double Triangle::getWidth() const
{
	return Width;
}
void Triangle::setHeight(double height)
{
	Height=height;
}
double Triangle::getHeight() const
{
	return Height;
}
void Triangle::drawTriangle(double width,double height) const
{
	int x,y;
	char ch='#';
	x=Triangle::getWidth();
	y=Triangle::getHeight();
	cout<<"This is a "<<Shape::getColors()<<" triangle with width "<<Width<<" and height "<<Height<<":"<<endl;
	for(int i=0;i<x;i++) 
		{
			if(i==x/2) cout<<ch;
			else cout<<" ";
		}
		cout<<"\n";
	for(int i=1;i<y-1;i++)//y hang
	{
		for(int j=0;j<x;j++)
		{
			if(j==(x/2-i)||j==(x/2+i)) cout<<ch;
			else cout<<" ";
		}
		cout<<"\n";
	}
	for(int i=0;i<=x;i++) cout<<ch;
		cout<<"\n";
}
void Triangle::printColor() const
{
	cout<<"This triangle is in ";
	Shape::printColor();
}
void Triangle::draw() const
{

	Triangle::drawTriangle(Width,Height);
}
double Triangle::saveArea() const
{
	double x,y;
	x=Triangle::getWidth();
	y=Triangle::getHeight();
	cout<<"Triangle's area = "<<(x*y)/2<<endl;
	return (x*y)/2;
}

