/*************************************************************************
	> File Name: circle.h
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:05:29 PM CDT
 ************************************************************************/
#ifndef CIRCLE_H
#define CIRCLE_H
#include <cstdlib>
#include <iostream>
#include <string>
#include "shape.h"
using namespace std;
class Circle: public Shape
{

	public:
		Circle(const string &,double=0.0);
		virtual ~Circle(){}
		void setRadius(double);
		double getRadius() const;
		void drawCircle(double) const;
		
		virtual void printColor() const override;
		virtual void draw() const override;
		virtual double saveArea() const override;
	protected:
		double Radius;

};


#endif