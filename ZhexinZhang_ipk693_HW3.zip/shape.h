/*************************************************************************
	> File Name: shape.h
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:05:11 PM CDT
 ************************************************************************/
#ifndef SHAPE_H
#define SHAPE_H
#include <cstdlib>
#include <iostream>
#include <string>
using namespace std;
class Shape
{
	public:
		Shape(const string &);

		void setColors(const std::string &);
		string getColors() const;
		
		
		virtual void printColor() const;
		virtual void draw() const;
		virtual double saveArea() const=0;
	protected:
		string colors;
};

#endif
