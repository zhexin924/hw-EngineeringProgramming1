/*************************************************************************
	> File Name: square.cpp
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:06:13 PM CDT
 ************************************************************************/

#include <cstdlib>
#include <iostream>
#include "shape.h"
#include <string>
#include "square.h"	
using namespace std;
Square::Square(const string & color,double width,double height):Shape(color)
{
	setWidth(width);
	setHeight(height);
}
void Square::setWidth(double width)
{
	Width=width;
}	
double Square::getWidth() const
{
	return Width;
}
void Square::setHeight(double height)
{
	Height=height;
}
double Square::getHeight() const
{
	return Height;
}
void Square::drawSquare(double width,double height) const
{
	double x,y;
	char ch='#';
	x=Square::getWidth();
	y=Square::getHeight();
	cout<<"This is a "<<Shape::getColors()<<" square with width "<<Width<<" and height "<<Height<<":"<<endl;
	for(double i = 0; i < x; i++)
	{
		cout<<ch; 
	}
		cout<<"\n";
	for(double i = 0; i < y - 2; i++) 
	{        
		cout<<ch;
		for(double j = 0; j < x-2; j++) cout<<" ";
		cout<<ch;
    	cout<<"\n";
	}
	for(double i = 0;i < x; i++) cout<<ch;
		cout<<"\n";

}
void Square::printColor() const
{
	cout<<"This square is in ";
	Shape::printColor();
}
void Square::draw() const
{

	Square::drawSquare(Width,Height);
}
double Square::saveArea() const
{
	double x,y;
	x=Square::getWidth();
	y=Square::getHeight();
	cout<<"Square's area = "<<(x*y)<<endl;
	return (x*y);
}
