/*************************************************************************
	> File Name: test.cpp
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:06:52 PM CDT
 ************************************************************************/

#include <cstdlib>
#include <iostream>
#include <vector>;
#include "shape.h"
#include"circle.h"
#include "triangle.h"
#include "square.h"
using namespace std;
int main()
{
	Circle circle1("red",1.0);
	Square square1("blue",6.5,9);
	Triangle triangle1("green",6.4,4);
	circle1.printColor();
	square1.printColor();
	triangle1.printColor();
	vector <Shape *> shapes(3);
	shapes[1]=&circle1;
	shapes[2]=&square1;
	shapes[0]=&triangle1;
	shapes[1]->line(0,1,0.5,1);
 
 shapes[1]->saveArea();
 shapes[2]->saveArea();
 shapes[0]->saveArea();
 shapes[1]->draw();
 shapes[2]->draw();
 shapes[0]->draw();
}
