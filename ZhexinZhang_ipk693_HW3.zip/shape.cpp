/*************************************************************************
	> File Name: shape.cpp
	> Author: Zhexin Zhang
	> Mail: jessicazhang0924@hotmail.com
	> Created Time: Wed 16 Mar 2016 04:04:47 PM CDT
 ************************************************************************/

#include <cstdlib>
#include <iostream>
#include "shape.h"
using namespace std;
Shape::Shape(const string &color):colors(color)
{
	//setColors(color);
}
void  Shape::setColors(const string &color) 
{
	colors=color;
}
string Shape::getColors() const
{
 return colors;
}

void Shape::printColor() const
{
	cout<<colors<<endl;
}
void Shape::draw() const
{
	cout<<"Want to draw something?My friends can draw circles,triangles,and squares for you!"<<endl;
}
