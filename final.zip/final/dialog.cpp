#include "dialog.h"
#include "ui_dialog.h"
#include "cpu.cpp"
#include <QString>
#include <QDebug>
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    CPU cpu;
    ui->setupUi(this);
    display();
    ui->next->setEnabled(false);
}

Dialog::~Dialog()
{
    delete ui;
}
void Dialog::on_reset_clicked()
{
    cpu.initialize();
    display();
    ui->start->setEnabled(true);
    ui->next->setEnabled(false);
}
void Dialog::on_start_clicked()
{
    QString input=ui->plainTextEdit->toPlainText();
    instructions=input.split("\n");
    cpu.IR=instructions[0];
    cpu.PC++;
    cpu.IF_ins=instructions[0];
    display();
    ui->start->setEnabled(false);
    ui->next->setEnabled(true);
}
void Dialog::on_next_clicked()
{
    if(cpu.PC<instructions.size())
    {
        cpu.WB_next();
        cpu.MEM_next();
        cpu.EXE_next();
        cpu.ID_next();
        cpu.IF_next(instructions[cpu.PC]);
    }
    else
    {
        cpu.WB_next();
        cpu.MEM_next();
        cpu.EXE_next();
        cpu.ID_next();
        cpu.IF_next("");
    }
    display();
}

void Dialog::display()
{
    //show each register and control signal
    ui->A->setText(QString::number(cpu.A));
    ui->B->setText(QString::number(cpu.B));
    ui->BTAKEN->setText(QString::number(cpu.BTAKEN));
    ui->C->setText(QString::number(cpu.C));
    ui->D->setText(QString::number(cpu.D));
    ui->EXE_ADEPEN->setText(QString::number(cpu.EXE_ADEPEN));
    QString temp(QString::number(cpu.EXE_ALUOP[1])+QString::number(cpu.EXE_ALUOP[0]));
    ui->EXE_ALUOP->setText(temp);
    ui->EXE_BDEPEN->setText(QString::number(cpu.EXE_BDEPEN));
    ui->EXE_d->setText(QString::number(cpu.EXE_d));
    ui->EXE_ins->setText(cpu.EXE_ins);
    ui->I->setText(QString::number(cpu.I));
    ui->ID_d->setText(QString::number(cpu.ID_d));
    ui->ID_ins->setText(cpu.ID_ins);
    ui->IF_ins->setText(cpu.IF_ins);
    ui->IR->setText(cpu.IR);
    ui->ID_SST->setText(QString::number(cpu.ID_SST));
    ui->LOADDEPEN->setText(QString::number(cpu.LOADDEPEN));
    ui->MEM_d->setText(QString::number(cpu.MEM_d));
    ui->MEM_ins->setText(cpu.MEM_ins);
    ui->MEM_WMEM->setText(QString::number(cpu.MEM_WMEM));
    ui->PC->setText(QString::number(cpu.PC));
    ui->R->setText(QString::number(cpu.R));
    ui->r1->setText(QString::number(cpu.reg[1]));
    ui->r2->setText(QString::number(cpu.reg[2]));
    ui->r3->setText(QString::number(cpu.reg[3]));
    ui->r4->setText(QString::number(cpu.reg[4]));
    ui->r5->setText(QString::number(cpu.reg[5]));
    ui->r6->setText(QString::number(cpu.reg[6]));
    ui->r7->setText(QString::number(cpu.reg[7]));
    ui->r8->setText(QString::number(cpu.reg[8]));
    ui->r9->setText(QString::number(cpu.reg[9]));
    ui->S->setText(QString::number(cpu.S));
    ui->WB_ins->setText(cpu.WB_ins);
    ui->WB_SLD->setText(QString::number(cpu.WB_SLD));
    ui->WB_WREG->setText(QString::number(cpu.WB_WREG));
    ui->WIR->setText(QString::number(cpu.WIR));
    ui->WPC->setText(QString::number(cpu.WPC));
    ui->EXE_WZ->setText(QString::number(cpu.EXE_WZ));
    ui->Z->setText(QString::number(cpu.Z));
}
