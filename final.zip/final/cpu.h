#ifndef CPU_H
#define CPU_H

#include <QString>
class CPU
{
    public:
        //registers
        int reg[10];
        //IF
        int PC,DSE;
        QString IR;
        //ID
        int ID_d,A,B,I;
        //EXE
        int EXE_d,Z,R,S,EXE_c;
        //MEM
        int MEM_d,D,C;
        //control signal
        int WPC,WIR,BTAKEN;
        int ID_SST,ID_BDEPEN,ID_ADEPEN,ID_ALUOP[2],ID_WZ,ID_WMEM,ID_SLD,ID_WREG,ID_rs2IsReg,success,LOADDEPEN;
        int EXE_BDEPEN,EXE_ADEPEN,EXE_ALUOP[2],EXE_WZ,EXE_WMEM,EXE_SLD,EXE_WREG,EXE_rs2IsReg;
        int MEM_WMEM,MEM_SLD,MEM_WREG,MEM_WZ;
        int WB_SLD,WB_WREG;
        QString ID_OPCODE,EXE_OPCODE,MEM_OPCODE,WB_OPCODE;
        QString IF_ins,ID_ins,EXE_ins,MEM_ins,WB_ins;
        CPU();
        void initialize();
        void IF_next(QString);
        void ID_next();
        void EXE_next();
        void MEM_next();
        void WB_next();
        void setZero();

};
#endif // CPU_H
