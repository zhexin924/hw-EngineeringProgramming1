#include <QDebug>
#include <QString>
#include "cpu.h"

CPU::CPU()
{
    initialize();
}
void CPU::initialize()
{
    for(int i=0;i<10;i++) reg[i]=0;
    PC=0;IR="";DSE=0;
    ID_d=0;A=0;B=0;I=0;
    EXE_d=0;Z=0;R=0;
    S=0;EXE_c=0;//EXE_D=0;//duole yieg exe_D?
    MEM_d=0;D=0;C=0;
    WPC=1;WIR=1;BTAKEN=0;
    ID_SST=0;ID_BDEPEN=0;ID_ADEPEN=0;ID_ALUOP[0]=0;ID_ALUOP[1]=0;ID_WZ=0;ID_WMEM=0;ID_SLD=0;ID_WREG=0;ID_rs2IsReg=0;success=0;LOADDEPEN=0;
    EXE_BDEPEN=0;EXE_ADEPEN=0;EXE_ALUOP[0]=0;EXE_ALUOP[1]=0;EXE_WZ=0;EXE_WMEM=0;EXE_SLD=0;EXE_WREG=0;EXE_rs2IsReg=0;
    MEM_WMEM=0;MEM_SLD=0;MEM_WREG=0;//MEM_WZ=0;
    WB_SLD=0;WB_WREG=0;
    ID_OPCODE="";EXE_OPCODE="";MEM_OPCODE="";WB_OPCODE="";
    IF_ins="";ID_ins="";EXE_ins="";MEM_ins="";WB_ins="";
}
void CPU::IF_next(QString instruction)
{
    IF_ins=instruction;
    if(BTAKEN==0)
    {
        if(WIR==1)
        {
            IR=instruction;
            IF_ins=instruction;
        }
        if(WPC==1) PC+=1;
    }
    else
    {
        if(WIR==1) IR=instruction;
        if(WPC==1) PC+=DSE;
        BTAKEN=0;
    }
}
void CPU::ID_next()
{
    //if need transfer,insert nop
    if(WIR==0&&success==0)
    {
        ID_OPCODE="nop";
        ID_ins="nop";
        setZero();
        WIR=1;
        return;
    }
    //if LOADDEPEN is 1,then we don't read new instruction from IR,to make it stop
    if(LOADDEPEN)
    {
        LOADDEPEN=0;
        WPC=1;
    }
    else ID_ins=IR;
    //if no instructions come in
    if(ID_ins=="")
    {
        setZero();
        return;
    }
    QStringList split_ins=ID_ins.split(" ");
    QStringList op;
    ID_OPCODE=split_ins[0];
    //if it's a branch instruction(we need solve control hazard)
    if(ID_OPCODE=="branch")
    {
        WIR=0;
        BTAKEN=1;
        DSE=split_ins[1].toInt();
        setZero();
        return;
    }
    if(ID_OPCODE=="bne"||ID_OPCODE=="beq")
    {
        if(EXE_WZ==1)
        {
            setZero();
            WPC=0;
            WIR=0;
            success=1;
            return;
        }
        else if(EXE_WZ==0)
        {
            if((ID_OPCODE=="bne"&&Z==0)||(ID_OPCODE=="beq"&&Z==1))
            {
                BTAKEN=1;
                DSE=split_ins[1].toInt();
            }
            else
            {
                BTAKEN=0;
                WIR=1;
            }
            WPC=1;
            success=0;
            return;
        }
    }
    //if it's not brach instruction,we need to make sure the ALUOP signal
    if(ID_OPCODE=="or"||ID_OPCODE=="ori"||ID_OPCODE=="sub"||ID_OPCODE=="subi")
        ID_ALUOP[0]=1;
    else ID_ALUOP[0]=0;
    if(ID_OPCODE=="add"||ID_OPCODE=="addi"||ID_OPCODE=="sub"||ID_OPCODE=="subi"||ID_OPCODE=="load"||ID_OPCODE=="store")
        ID_ALUOP[1]=1;
    else ID_ALUOP[1]=0;
    //find out SST signal
    if(ID_OPCODE=="store")
        ID_SST=1;
    else ID_SST=0;
    //find out WZ signal
    if(ID_OPCODE=="and"||ID_OPCODE=="or"||ID_OPCODE=="add"||ID_OPCODE=="sub"||ID_OPCODE=="andi"||ID_OPCODE=="ori"||ID_OPCODE=="addi"||ID_OPCODE=="subi")
        ID_WZ=1;
    else ID_WZ=0;
    //find out WREG signal
    if(ID_OPCODE=="and"||ID_OPCODE=="or"||ID_OPCODE=="add"||ID_OPCODE=="sub"||ID_OPCODE=="andi"||ID_OPCODE=="ori"||ID_OPCODE=="addi"||ID_OPCODE=="subi"||ID_OPCODE=="load")
        ID_WREG=1;
    else ID_WREG=0;
    //find out WMEM signal
    if(ID_OPCODE=="store") ID_WMEM=1;
    else ID_WMEM=0;
    //find out SLD signal
    if(ID_OPCODE=="load")
        ID_SLD=1;
    else ID_SLD=0;
    //find out ID_rs2IsReg signal
    if(ID_OPCODE=="and"||ID_OPCODE=="or"||ID_OPCODE=="add"||ID_OPCODE=="sub")
        ID_rs2IsReg=1;
    else ID_rs2IsReg=0;
    //find out the operands by opcode
    if(ID_WZ==1)
    {
        op=split_ins[1].split(",");
    }
    else if (ID_OPCODE=="load"||ID_OPCODE=="store")
    {
        //if it's load or store instruction
        op.push_back(split_ins[1].mid(0,2));
        int rear=split_ins[1].indexOf("(");
        int front=split_ins[1].indexOf(",");
        op.push_back(split_ins[1].mid(rear+1,2));
        op.push_back(split_ins[1].mid(front+1,rear-front-1));
    }
    //write data into d,A,B,I
    QString temp;
    temp=op[0][1];
    ID_d=temp.toInt();
    temp=op[1][1];
    int rs1=temp.toInt();
    int rs2;
    A=reg[rs1];
    if(ID_rs2IsReg==1)
    {
        temp=op[2][1];
        rs2=temp.toInt();
        B=reg[rs2];
        I=rs2;
    }
    else if (ID_SST==1)
    {
        temp=op[0][1];
        B=reg[temp.toInt()];
        rs2=B;
        temp=op[2].toInt();
        I=temp.toInt();
    }else
    {
        I=op[2].toInt();
        rs2=I;
    }
    //find out if it's data hazard according to ADEPEN and BDEPEN signal
    if(EXE_WREG==1&&rs1==EXE_d) ID_ADEPEN=2;
    else if(MEM_WREG==1&&rs1==MEM_d) ID_ADEPEN=3;
    else ID_ADEPEN=0;
    if(ID_rs2IsReg==0) ID_BDEPEN=1;
    else if (EXE_WREG==1&&rs2==EXE_d)
        ID_BDEPEN=2;
    else if(MEM_WREG==1&&rs2==MEM_d) ID_BDEPEN=3;
    else ID_BDEPEN=0;
    //realize load
    if((EXE_SLD==1&&rs1==EXE_d)||(EXE_SLD==1&&rs2==EXE_d&&ID_rs2IsReg))
    {
        WPC=0;
        ID_WMEM=0;
        ID_WREG=0;
        ID_WZ=0;
        LOADDEPEN=1;
    }
    else
    {
        WPC=1;
        LOADDEPEN=0;
    }
    if(MEM_SLD==1&&rs1==MEM_d) ID_ADEPEN=3;
    if(MEM_SLD==1&&rs2==MEM_d&&ID_rs2IsReg) ID_BDEPEN=3;



}
void CPU::EXE_next()
{
    if(LOADDEPEN)
    {
        EXE_ins="nop";EXE_WMEM=0;
        EXE_WREG=0;EXE_WZ=0;
        EXE_ADEPEN=0;EXE_BDEPEN=0;
        EXE_ALUOP[0]=0;EXE_ALUOP[1]=0;
        EXE_d=0;EXE_OPCODE="nop";
        EXE_rs2IsReg=0;
        EXE_SLD=0;
        R=0;S=0;
        return;
    }
    EXE_ins=ID_ins;
    EXE_ADEPEN=ID_ADEPEN;
    EXE_BDEPEN=ID_BDEPEN;
    EXE_ALUOP[0]=ID_ALUOP[0];
    EXE_ALUOP[1]=ID_ALUOP[1];
    EXE_d=ID_d;
    EXE_OPCODE=ID_OPCODE;
    EXE_rs2IsReg=ID_rs2IsReg;
    EXE_SLD=ID_SLD;
    EXE_WMEM=ID_WMEM;
    EXE_WREG=ID_WREG;
    EXE_WZ=ID_WZ;
    S=B;
    //bne or beq need to wait for register Z to be ready,so it need a pause;
    if((EXE_OPCODE=="bne"||EXE_OPCODE=="beq")&&MEM_WZ==1)
    {
        EXE_OPCODE="nop";
        EXE_ins="nop";
    }
        int a=0,b=0;
        //MUX
        switch(EXE_ADEPEN)
        {
            case 0:a=A;break;
            case 2:a=R;break;
        case 3:a=WB_SLD?EXE_d:EXE_c;break;//getting data from D or C determined by WB_SLD
        }
        switch(EXE_BDEPEN)
        {
            case 0: b=B;break;
            case 1:b=I;break;
            case 2:b=R;break;
            case 3:b=WB_SLD?EXE_d:EXE_c;break;
        }
        //ALU calculation
        if(EXE_ALUOP[1]==0&&EXE_ALUOP[0]==0)
        {
            R=a&b;
        }else if(EXE_ALUOP[1]==0&&EXE_ALUOP[0]==1)
        {
            R=a|b;
        }else if(EXE_ALUOP[1]==1&&EXE_ALUOP[0]==0)
        {
            R=a+b;
        }else if(EXE_ALUOP[1]==1&&EXE_ALUOP[0]==1)
        {
            R=a-b;
        }
        if(EXE_WZ==1&&R==0) Z=1;
        if(EXE_WZ==1&&R!=0) Z=0;
    }


void CPU::MEM_next()
{
    MEM_ins=EXE_ins;
    MEM_WMEM=EXE_WMEM;
    MEM_OPCODE=EXE_OPCODE;
    MEM_SLD=EXE_SLD;
    MEM_WREG=EXE_WREG;
    MEM_WZ=EXE_WZ;
    MEM_d=EXE_d;
    C=R;
    EXE_c=R;
    //because this simulation doesn't focus on load and store,so we simplify this part
    //that is we don't actually store,just set load instruction will get 9
    if(MEM_OPCODE=="load") D=9;
    else D=0;
    EXE_d=D;
}
void CPU::WB_next()
{
    WB_ins=MEM_ins;
    WB_SLD=MEM_SLD;
    WB_WREG=MEM_WREG;
    WB_OPCODE=MEM_OPCODE;
    if(WB_WREG==1)
    {
        if(WB_SLD==1) reg[MEM_d]=D;
        else reg[MEM_d]=C;
    }
}
void CPU::setZero()
{
    ID_d=0;
    A=0;
    B=0;
    I=0;
    ID_SST=0;
    ID_BDEPEN=0;
    ID_ADEPEN=0;
    ID_ALUOP[0]=0;
    ID_ALUOP[1]=0;
    ID_WZ=0;
    ID_WMEM=0;
    ID_SLD=0;
    ID_WREG=0;
    ID_rs2IsReg=0;
}
