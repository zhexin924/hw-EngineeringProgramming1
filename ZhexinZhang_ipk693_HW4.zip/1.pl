#! usr/bin/perl -w
#use strict;
print "Please tell me the temperature:";
while($input=<STDIN>)
{
chomp($input);
	if($input=~/(\d)(\.?)(F|f)/)
	{
		chop($input);		
		$C=($input-32)/1.8;
		print "It is $C Celsius.\n";
	}
	elsif($input=~/(\d)(\.?)(C|c)/)
	{
		chop($input);		
		$F=$input*1.8+32;
		print "It is $F Fahrenheit.\n";
	}
	elsif($input=~/(q|Q)/)
	{
		exit();
	}
	else
	{
		print"Sorry,I can't understand what do you mean.Please re enter:\n";
		next;
	}
	print "DO you want to go on convertion?\nIf yes,just keep on typing in,if not please input q or Q to quit!\n";
}
