#! usr/bin/perl -w

$_="alice: 49239
# bob is a good student
 bob:20394
# charlie: 12039 will be changed to charlie:00000
charlie :12039
denise : 20033";
$i=0;
foreach $old(split /\n/,$_)
{
	#print "行$old\n";


	if($old=~/(([a-z]+)(\s?):(\s?)(\d+)(([a-z]*)(\s?)(:?)(\s?)(\d*)))/)
		{
			#print "$1\n" if defined $1;
			#@new;
			$new[$i]=$1;
			$i++;
		}

}
foreach $before(@new)
{
	@almost=split /\s?:\s?/,$before;
	#print"@almost\n";
	#%hash;
	$hash{$almost[0]}=$almost[1];
}
print "In the hash which use student names as keys and student numbers as values,it has following pairs:\n";		
foreach (keys(%hash))
{
	print"$_=>$hash{$_}\n";
}
