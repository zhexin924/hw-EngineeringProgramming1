#usr/bin/perl -w
#use strict;
$_= "We hired John in 2014-02-28. He is working on product 1023-45-002X. John entered UTSA 2009-10-16 and graduate in 2013-05-30.";
@months=("January","February","March","April","May","June","July","August","September","October","November","December");
$i=0;

foreach $word(split /\s/,$_)
{
	
	if($word=~/((\d\d\d\d)-(\d\d)-(\d\d(\b|\W)))/)
	{
		@old;
		$old[$i]=$word;
		#print "$word\n";
		@date=split /-|\./, $word;
		#print"@date\n";
		@new;
		$new[0]=$months[$date[1]-1];
		$new[1]=$date[2];
		$new[2]=$date[0];
		$word1[$i]="$new[0] $new[1],$new[2]";
		$i++;
	}
}
for($i=0;$i<=$#old;$i++)
{
	s/$old[$i]/$word1[$i]/;
}
print $_;
