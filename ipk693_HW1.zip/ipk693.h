#ifndef IPK693_HW1_2_H
#define IPK693_HW1_2_H



#include<iostream>
using namespace std;
class Complex
{
   private:
	int real,imaginary;
   public:
	explicit Complex (int r,int i)；
	void printComplex()；
	Complex add(Complex c2)；	
};

#endif
