#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int deci,i=0,j=0,remainder,temp,bi[1000];
	char hexa[250];
	cout<<"Enter a decimal number:";
	cin>>deci;
	if(deci/2!=0)//if decimal number is lager than 1
	{
		temp=deci;//set a temp value so it will not change the value of deci
		while(temp>0)//turn the decimal number into binary 
		{
			remainder=temp%2;
			temp=temp/2;
			bi[i++]=remainder;	
		}
		cout<<"Binary number:";
		while(i>0)//output binary number
		cout<<bi[--i];
	}
	else cout<<"Binary number:"<<deci<<endl;
	cout<<"\n";
	if(deci/16)
	{
		temp=deci;//reset temp for turn the decimal number into hexadecimal 	   
        while(temp>0)
        {
        	remainder=temp%16;
        	temp=temp/16;
        	hexa[j++]=(remainder>=10?('A'+remainder-10):(remainder+'0'));//if this bit is larger than 10,save it's hex value
        }	  
		cout<<"Hexadecimal number:"<<"0X";
		while(j>0)
		{
			cout<<hexa[--j];
		}
	}
	else cout<<"Hexadecimal number:0X"<<char((deci>=10?('A'+deci-10):(deci+'0')))<<endl;
	
}
