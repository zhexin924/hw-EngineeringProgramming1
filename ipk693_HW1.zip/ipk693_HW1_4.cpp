#include<iostream>
using namespace std;

int main()
{
	float center[2],point[2],c;
	cout<<"Enter a center:";
	cin>>center[0]>>center[1];
	cout<<"Enter a radius:";
	cin>>c;
	cout<<"Enter a point to test:";
	cin>>point[0]>>point[1];
	cout<<"Result:";
	if(c<0)
	cout<<"Input point error";
	else if((point[0]-center[0])*(point[0]-center[0])+(point[1]-center[1])*(point[1]-center[1])<c*c)
		cout<<"Inside";
	else if((point[0]-center[0])*(point[0]-center[0])+(point[1]-center[1])*(point[1]-center[1])==c*c)
		cout<<"On the circle";
	else if((point[0]-center[0])*(point[0]-center[0])+(point[1]-center[1])*(point[1]-center[1])>c*c)
		cout<<"Outside";
	 
	return 0;
}
