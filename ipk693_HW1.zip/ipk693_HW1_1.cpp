#include<iostream>
using namespace std;

int main()
{
float Euro,Dollar;
const float rate=0.93;
cout<<"Tell me how many dollars do you have:";
cin>>Dollar;
Euro=Dollar*rate;
cout.setf(ios::fixed);
cout.precision(2);
cout<<"It's "<<Euro<<"Euros."<<endl;
return 0;
}
