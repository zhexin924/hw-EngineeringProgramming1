#include<iostream>
#include"ipk693.h"
explicit Complex (int r,int i)
{
	real=r;
	imaginary=i;
}
void Complex∷printComplex()
{
	cout<<real<<"+"<<imaginary<<"i"<<endl;
}
Complex Complex∷add(Complex c2)
{
	Complex c1(real,imaginary),c(real,imaginary);
	c1.real=c.real+c2.real;
	c1.imaginary=c.imaginary+c2.imaginary;
	return (c1);
}

